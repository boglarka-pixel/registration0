import firestore from './firestore';

const db = firestore();

export default db;
