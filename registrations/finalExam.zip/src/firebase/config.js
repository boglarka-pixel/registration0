const config = {
    apiKey: "AIzaSyBMR-_D5lWufgy18QtK5HbOaNujB_2mC-g",
    authDomain: "exam-practice-30a0b.firebaseapp.com",
    projectId: "exam-practice-30a0b",
    storageBucket: "exam-practice-30a0b.appspot.com",
    messagingSenderId: "224629331915",
    appId: "1:224629331915:web:227b912178ba302ecdc84e"
};

export default config;