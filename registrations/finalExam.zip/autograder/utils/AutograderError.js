

module.exports = class AutograderError extends Error {
    constructor(message) {
        super(message);
    }
}
